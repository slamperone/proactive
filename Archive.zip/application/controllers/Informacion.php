<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Informacion extends CI_Controller {

	public function index()
	{
		$this->load->view('top');
		$this->load->view('cultura');
		$this->load->view('bottom');
	}
	public function cultura_corporativa()
	{
		$this->load->view('top');
		$this->load->view('cultura');
		$this->load->view('bottom');
	}
	public function infdex()
	{
		$this->load->view('top');
		$this->load->view('cultura');
		$this->load->view('bottom');
	}
	public function insdex()
	{
		$this->load->view('top');
		$this->load->view('cultura');
		$this->load->view('bottom');
	}
	public function iandex()
	{
		$this->load->view('top');
		$this->load->view('cultura');
		$this->load->view('bottom');
	}
	public function infdsex()
	{
		$this->load->view('top');
		$this->load->view('cultura');
		$this->load->view('bottom');
	}
	public function indefx()
	{
		$this->load->view('top');
		$this->load->view('cultura');
		$this->load->view('bottom');
	}
}
