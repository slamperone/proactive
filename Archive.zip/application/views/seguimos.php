 <!-- contenido -->
   <section class="generic animated fadeInUp delay1">
      <div class="container">

         <!-- title -->
         <div class="row text-center title">
         	<br /><br /><br />
           <h1>Seguimos trabajando</h1>
         </div>
         <!-- end title -->

                     <img src="<?= base_url('assets/img/proactive-semiologia-logotipo.png'); ?>" alt="proactive semiología"/>

</div>
</section>