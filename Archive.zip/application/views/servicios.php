 <!-- contenido -->
   <section class="generic animated fadeInUp delay1">
      <div class="container">

         <!-- title -->
         <div class="row text-center title">
           <?php if (isset($titulo) && $titulo != "") {echo '<h1>'.$titulo.'</h1>';}  ?>
                      <?php if (isset($subtitulo) && $subtitulo != "") {echo '<h2>'.$subtitulo.'</h2>';}  ?>

         </div>
         <!-- end title -->


          <div class="row">

            <div class="col-md-8">
               <h3>Consultoría empresarial y Acompañamiento: </h3>
               <p>Por este medio detectamos las áreas de oportunidad para impartir la capacitación a la medida de las necesidades específicas del cliente.</p>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>

</section>

<section class="spaceServ generic animated fadeInUp delay2">
	<div class="container">
          <div class="row">

          	<div class="col-md-4"></div>

            <div class="col-md-8">
               &nbsp;
            </div>

        </div>



          <div class="row">
<div class="col-md-4"></div>
            <div class="col-md-8">
               <h3>Consultoría individual, cursos y talleres:</h3>
               <p>Contamos con la ventaja de poder seleccionar a sugerencia del cliente, la línea más adecuada de entrenamiento individual y grupal.</p>
            </div>

        </div>

    </div>
</section>
<section>
	<div class="container generic animated fadeInUp delay2">


          <div class="row">

            <div class="col-md-8">
               <h3>Seguimiento personalizado:</h3>
               <p>Ofrecemos un apoyo adicional de asesoría a través de una retroalimentación con técnicas que inspiren creatividad e innovación.</p>
            </div>
            <div class="col-md-4"></div>
        </div>




        </div>
    </section>
