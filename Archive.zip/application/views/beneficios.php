 <!-- contenido -->
   <section class="generic animated fadeInUp delay1">
      <div class="container">

         <!-- title -->
         <div class="row text-center title">
           <?php if (isset($titulo) && $titulo != "") {echo '<h1>'.$titulo.'</h1>';}  ?>
                      <?php if (isset($subtitulo) && $subtitulo != "") {echo '<h2>'.$subtitulo.'</h2>';}  ?>

         </div>
         <!-- end title -->


          <div class="row">

            <div class="col-md-12">
              <ul class="difi">
                 <li><i class="icon-flash"></i>Generar autonomía de gestión</li>
                 <li><i class="icon-flash"></i>Formar a lideres y dirigentes</li>
                 <li><i class="icon-flash"></i>Aumento de la eficacia organizacional</li>
                 <li><i class="icon-flash"></i>Mejoramiento de la imagen de la empresa</li>
                 <li><i class="icon-flash"></i>Mejoramiento de clima organizacional</li>
                 <li><i class="icon-flash"></i>Facilidad en los cambios y en la innovación</li>
                 <li><i class="icon-flash"></i>Aumento de eficiencia de los empleados</li>
                 <li><i class="icon-flash"></i>Generar sentido de pertenencia a la empress</li>
                 <li><i class="icon-flash"></i>Aumento de la productividad</li>
                 <li><i class="icon-flash"></i>Mejoramiento de la calidad de los productos y servicios</li>
                 <li><i class="icon-flash"></i>Mayor eficiencia en el manejo de recursos</li>
            </div>
        </div>

        <div class="row text-center frase1">
           <h2>“Si usted opina que la capacitación es cara, es por que no sabe lo que le cuesta la ignorancia...”</h2>
         </div>
    </div>
</section>