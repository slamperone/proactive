<div style="width: 500px; height: 800px; background-color: #2190C8;">
<h1>Ola ke ase</h1>

</div>